import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

public class Crypto {
    private String key;
    private File inputFileName;
    private File outputFileName;
    public Crypto setKey(String key) {
        this.key = key;
        return this;
    }

    public Crypto setInputFileName(File inputFileName) {
        this.inputFileName = inputFileName;
        return this;
    }
    public Crypto setOutputFileName(File outputFileName) {
        this.outputFileName = outputFileName;
        return this;
    }
    public void encrypt() {
        fileProcessor(Cipher.ENCRYPT_MODE);
    }

    public void decrypt() {
        fileProcessor(Cipher.DECRYPT_MODE);
    }

     void fileProcessor(int cipherMode){
        try {
            Key secretKey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(cipherMode, secretKey);

            FileInputStream inputStream = new FileInputStream(inputFileName);
            byte[] inputBytes = new byte[(int) inputFileName.length()];
            inputStream.read(inputBytes);

            byte[] outputBytes = cipher.doFinal(inputBytes);

            FileOutputStream outputStream = new FileOutputStream(outputFileName);
            outputStream.write(outputBytes);

            inputStream.close();
            outputStream.close();

        } catch (NoSuchPaddingException | NoSuchAlgorithmException
                | InvalidKeyException | BadPaddingException
                | IllegalBlockSizeException | IOException e) {
            e.printStackTrace();
        }
    }

}
