
import java.io.File;

public class main{

    public static void main(String[] args) {
//        String key = AwsParameterStore.getParameter("AutomationCryptoKey");
        String key="kXp2s5v8y/A?D(G+KbPeShVmYq3t6w9z";
        File inputFile = new File("src/test/resources/crpto/"+args[0]);
        File encryptedFile = new File("src/test/resources/crpto/"+args[0]+".cph");
         try {
            Crypto crypto= new Crypto();
            crypto.setInputFileName(inputFile).setKey(key).setOutputFileName(encryptedFile).encrypt();
            inputFile.deleteOnExit();
            System.out.println("Success");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }
}
